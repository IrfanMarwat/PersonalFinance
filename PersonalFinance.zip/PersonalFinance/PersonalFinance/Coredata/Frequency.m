//
//  Frequency.m
//  PersonalFinance
//
//  Created by Irfan on 9/11/16.
//  Copyright © 2016 Irfan. All rights reserved.
//

#import "Frequency.h"

@implementation Frequency

// Insert code here to add functionality to your managed object subclass

@end
