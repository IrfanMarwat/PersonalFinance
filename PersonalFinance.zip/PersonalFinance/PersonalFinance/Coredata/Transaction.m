//
//  Transaction.m
//  PersonalFinance
//
//  Created by Irfan on 9/11/16.
//  Copyright © 2016 Irfan. All rights reserved.
//

#import "Transaction.h"
#import "Account.h"

@implementation Transaction

// Insert code here to add functionality to your managed object subclass

@end
