//
//  DasboardCellData.m
//  PersonalFinance
//
//  Created by Irfan on 9/11/16.
//  Copyright © 2016 Irfan. All rights reserved.
//

#import "DashboardCellData.h"

@implementation DashboardCellData

@end
